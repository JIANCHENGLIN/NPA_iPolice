
  # 警政服務APP首頁設計

  This is a code bundle for 警政服務APP首頁設計. The original project is available at https://www.figma.com/design/LD9dUbWrF8TeeIteBH2hmQ/%E8%AD%A6%E6%94%BF%E6%9C%8D%E5%8B%99APP%E9%A6%96%E9%A0%81%E8%A8%AD%E8%A8%88.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  